-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- දායකයා: 127.0.0.1
-- උත්පාදන වේලාව: අගෝස්තු 19, 2020 දින 11:17 AM ට
-- සේවාදායකයේ අනුවාදය: 10.4.11-MariaDB
-- PHP අනුවාදය: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- දත්තගබඩාව: `lakehouse`
--

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `fullname` text NOT NULL,
  `name` text NOT NULL,
  `image` varchar(100) NOT NULL,
  `phoneno` int(10) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `images`
--

INSERT INTO `images` (`id`, `fullname`, `name`, `image`, `phoneno`, `description`) VALUES
(29686, 'Disna Loral Kumari', 'Disna Loral', '0.jfif', 713463266, 'testopo');

-- --------------------------------------------------------

--
-- වගුවක් සඳහා වගු සැකිල්ල `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- වගු සඳහා නික්ෂේප දත්ත `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'admin', '$2y$10$LSfGrI7njvwAfBv3qWIivOEG6f8XLTPd/HX194/CPXJlSrliS9nfW', '2020-03-03 23:23:41');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
