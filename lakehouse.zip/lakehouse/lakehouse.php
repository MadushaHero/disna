<?php


session_start();


 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}





  // Create database connection
  $db = mysqli_connect("localhost", "lakmal", "321", "lakehouse");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
	$empid = mysqli_real_escape_string($db, $_POST['empid']);
  	$user_name = mysqli_real_escape_string($db, $_POST['user_name']);
	$full_name = mysqli_real_escape_string($db, $_POST['full_name']);
	$phone = mysqli_real_escape_string($db, $_POST['phone']); 
	$descriptions = mysqli_real_escape_string($db, $_POST['descriptions']);
	/*
	echo $empid;
	echo "<br/>";
	echo $user_name;
	echo "<br/>";
	echo $full_name;
	echo "<br/>";
	echo $image;
	echo "<br/>";
	echo $phone;
	echo "<br/>";
	echo $descriptions;
	echo "<br/>";
	*/

  	// image file directory
  	$target = "images/".basename($image);

  	//$sql = "INSERT INTO images (id,fullname,name,image,phoneno,descriptions) VALUES ('$empid','$full_name','$user_name','$image','$phone','$descriptions')";
	$sql = "INSERT INTO images (id, fullname,name,image,phoneno,description) VALUES ('$empid', '$full_name','$user_name','$image','$phone','$descriptions')";
  	// execute query
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully";
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  //$result = mysqli_query($db, "SELECT * FROM images");
?>



 
<!DOCTYPE html PUBLIC “-//W3C//DTD XHTML 1.0 Strict//EN”
“http://www.w3.org/TR/xhtml/DTD/xhtml1-strict.dtd 24”>

<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif;  }
		
		 table { 
                border-collapse: collapse; 
            } 
            th { 
                background-color:green; 
                Color:white; 
            } 
            th, td { 
                width:150px; 
                text-align:center; 
                border:1px solid black; 
                padding:5px 
              
            } 
			
			.geeks { 
                border-right:hidden; 
            } 
            .gfg { 
                border-collapse:separate; 
                border-spacing:0 15px; 
            } 
            h1 { 
                color:green; 
            } 
		
    </style>
	
	<script> 
	function validateForm() {
  var x = document.forms["myForm"]["full_name"].value;
  var y = document.forms["myForm"]["user_name"].value;
  var z = document.forms["myForm"]["empid"].value;
  var z1 = document.forms["myForm"]["size"].value;
  var z2 = document.forms["myForm"]["phone"].value;
   var z3 = document.forms["myForm"]["descriptions"].value;
  
  
  if (x == "") {
    alert("Full Name must be filled out");
    return false;
  }
  
  if (y == "") {
    alert("Name must be filled out");
    return false;
  }
  
  if (z == "") {
    alert("Student Id");
    return false;
  }
  
  if (z1 == "") {
    alert("Image");
    return false;
  }
  
  if (z2 == "") {
    alert("Phone Number ");
    return false;
  }
  
  
  if (z3 == "") {
    alert("Descriptions");
    return false;
  }
  
  
  
}
</script> 	
	
</head>
<body>
<center>
    <div class="page-header">
        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>Welcome to  Lake House Employee Details Application .</h1>
    </div>
    <p>
              <a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
		<a href="lakehouse.php" class="btn btn-danger">Enter Employee  Details</a>
		<a href="welcome.php" class="btn btn-danger">Search Employee </a>
		<a href="all.php" class="btn btn-danger">ALL </a>
	   
	
    </p>
	
</center>
	<center>
	<table  class = "gfg" >	
	<form  name="myForm" method="post" action="lakehouse.php" enctype="multipart/form-data" onsubmit="return validateForm()" >
	
 
	<tr scope="row">
<td>Full Name: <font style="color:red">*</font> </td><td><input type="text" name="full_name" size="80" placeholder="Enter Student Name" /></td>
</tr>
<tr>
<td>Name : <font style="color:red">*</font></td>  <td><input type="text" name="user_name" size="50" placeholder="Enter Student Name" /></td>
</tr>
<tr>

<td>Employee Id :- <font style="color:red">*</font> </td> <td><input type="text" size="20"  name="empid" placeholder="Enter Student Number" /> </td>
</tr>


<tr>
<td>Image :</td>
<td><input type="hidden" name="size" value="1000000">
  	
  	  <input type="file" name="image">
  	
	:</td>
</tr>

<tr>
<td>Phone Number :- <font style="color:red">*</font></td> <td> <input type="tel"  name="phone" size="20" pattern="[0-9]{10}" placeholder="Phone Number" /></td> 
</tr>
<tr>
<td>Descriptions :- </td> <td><textarea name="descriptions" rows="4" cols="50" ></textarea></td>
</tr>
<tr>
<td>

</td>
<td>  <input name="upload" type="submit" value="Submit" />  <input type="reset" value="Reset" /> </td>
</tr>


</form>
	</table>
	</center>
	
	
</body>
</html>