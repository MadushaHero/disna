<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>


<?php

$updatedok="";

  // Create database connection
  $db = mysqli_connect("localhost", "lakmal", "321", "lakehouse");

  // Initialize message variable
  $msg = "";

  // If upload button is clicked ...
  if (isset($_POST['upload'])) {
  	// Get image name
  	$image = $_FILES['image']['name'];
  	// Get text
	$empid = mysqli_real_escape_string($db, $_POST['empid']);
  	$user_name = mysqli_real_escape_string($db, $_POST['user_name']);
	$full_name = mysqli_real_escape_string($db, $_POST['full_name']);
	$phone = mysqli_real_escape_string($db, $_POST['phone']); 
	$descriptions = mysqli_real_escape_string($db, $_POST['descriptions']);
	/*
	echo $empid;
	echo "<br/>";
	echo $user_name;
	echo "<br/>";
	echo $full_name;
	echo "<br/>";
	echo $image;
	echo "<br/>";
	echo $phone;
	echo "<br/>";
	echo $descriptions;
	echo "<br/>";
	*/

  	// image file directory
  	$target = "images/".basename($image);

  	//$sql = "INSERT INTO images (id,fullname,name,image,phoneno,descriptions) VALUES ('$empid','$full_name','$user_name','$image','$phone','$descriptions')";
	//$sql = "INSERT INTO images (id, fullname,name,image,phoneno,description) VALUES ('$empid', '$full_name','$user_name','$image','$phone','$descriptions')";
	
	
	
	$sql = "UPDATE images SET id = '$empid', fullname = '$full_name', name = '$user_name'  ,image='$image', phoneno='$phone',description='$descriptions' WHERE id = '$empid'" ; 
	
	//UPDATE MyGuests SET lastname='Doe' WHERE id=2
	
	
  	// execute query
  	mysqli_query($db, $sql);

  	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Image uploaded successfully"; 
  	}else{
  		$msg = "Failed to upload image";
  	}
  }
  
  //';
  if (isset($_GET['id'])) {
    $idvalue=$_GET['id'];
}

else
{
	//$idvalue=$empid;
	
	//if not pass
	
	
	header('Location: update.php?id='.$empid);
	
	
	
	//successfully updated Variable 

//$updatedok ="<center><font color='red'>Record Successfully updated !</center>";


	
	
	
	
}
  
  $result = mysqli_query($db, "SELECT * FROM images WHERE id='$idvalue'");
  
  



  
  
  
  
  
  
?>



 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif;  }
		
		 table { 
                border-collapse: collapse; 
            } 
            th { 
                background-color:green; 
                Color:white; 
            } 
            th, td { 
                width:150px; 
                text-align:center; 
                border:1px solid black; 
                padding:5px 
              
            } 
			
			.geeks { 
                border-right:hidden; 
            } 
            .gfg { 
                border-collapse:separate; 
                border-spacing:0 15px; 
            } 
            h1 { 
                color:green; 
            } 
		
    </style>
</head>
<body>
 <?php
    while ($row = mysqli_fetch_array($result)) {
      //echo "<div id='img_div'>";
      	$imageform = $row['image'];
		$idform = $row['id'];
		$fullnameform = $row['fullname'];
		$nameform = $row['name'];
		$imageform = $row['image'];
		$phonenoform = $row['phoneno'];
		$descriptionform = $row['description'];
		
		
		
      	//echo "<p>".$row['image_text']."</p>";
      //echo "</div>";
    }
  ?>


<center>
    <div class="page-header">
        <h1>Hi, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b>Welcome to  Lake House Employee Details Application .</h1>
    </div>
    <p>
               <a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger">Sign Out of Your Account</a>
		<a href="lakehouse.php" class="btn btn-danger">Enter Employee  Details</a>
		<a href="welcome.php" class="btn btn-danger">Search Employee </a>
		<a href="all.php" class="btn btn-danger">ALL </a>
		
    </p>
	
</center>
	<center>
	<table  class = "gfg" >	
	<form method="post" action="update.php" enctype="multipart/form-data">
	

	<tr scope="row">
<td>Full Name: </td><td><input type="text" name="full_name" size="80" placeholder="Enter Student Name" value='<?php echo $fullnameform; ?>' /></td>
</tr>
<tr>
<td>Name :</td>  <td><input type="text" name="user_name" size="50" placeholder="Enter Student Name" value='<?php echo $nameform; ?>' /></td>
</tr>
<tr>

<td>Student Id :- </td> <td><input type="text" size="20"  name="empid" placeholder="Enter Student Number" value='<?php echo $idform; ?>' /> </td>
</tr>
<tr>
<td>Image :</td>
<td>
  	<img src="<?php echo 'images/'.$imageform; ?>" width='70' height="90" alt="">
	</td>
</tr>

<tr>
<td>Change Image :</td>
<td><input type="hidden" name="size" value="1000000">
  	
  	  <input type="file" name="image">
  	
	:</td>
</tr>

<tr>
<td>Phone Number :-</td> <td> <input type="tel"  name="phone" size="20"  value='<?php echo $phonenoform; ?>' placeholder="Phone Number" /></td> 
</tr>
<tr>
<td>Descriptions :- </td> <td><textarea name="descriptions" rows="4" cols="50"  ><?php echo $descriptionform; ?></textarea></td>
</tr>
<tr>

<td>     </td>

<td>

<input name="upload" type="submit" value="Update" />
<a class="btn btn-link" href="welcome.php">Cancel</a>
</td>
</tr>


</form>
	</table>
	
	 <?php
	           echo $updatedok;
	 
	 ?>
	</center>
	
	
</body>
</html>